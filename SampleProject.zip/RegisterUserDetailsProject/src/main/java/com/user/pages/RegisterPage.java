package com.user.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.cucumber.listener.Reporter;
import com.user.utils.Entity;

public class RegisterPage extends CommonPageFactoryPage {
	public RegisterPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//a[text()='Register']")
	public WebElement registerLink;
	
	@FindBy(id = "customer.firstName")
	public WebElement firstNameTextBox;
	
	@FindBy(id = "customer.lastName")
	public WebElement lastNameTextBox;
	
	@FindBy(id = "customer.address.street")
	public WebElement addressTextBox;
	
	@FindBy(id = "customer.address.city")
	public WebElement cityTextBox;
	
	@FindBy(id = "customer.address.zipCode")
	public WebElement zipCodeTextBox;
	
	
	@FindBy(id = "customer.address.state") 
	public WebElement stateTextBox;
	 
	
	@FindBy(id = "customer.phoneNumber")
	public WebElement phoneNumTextBox;
	
	@FindBy(id = "customer.ssn")
	public WebElement ssnTextBox;
	
	@FindBy(id = "customer.username")
	public WebElement userNameTextBox;
	
	@FindBy(id = "customer.password")
	public WebElement passwordTextBox;
	
	@FindBy(id = "repeatedPassword")
	public WebElement confPassTextBox;
	
	@FindBy(xpath = "//input[@value='Register']")
	public WebElement registerButton;
	
	@FindBy(xpath = "//*[@id='rightPanel']/p")
	public WebElement successfulMessgae;
	
	public void clickRegisterLink() {
		registerLink.click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	}
	
	public String registerUserDetails(List<String> userDetails) throws InterruptedException {
		firstNameTextBox.sendKeys(userDetails.get(0));
		lastNameTextBox.sendKeys(userDetails.get(1));
		addressTextBox.sendKeys(userDetails.get(2));
		cityTextBox.sendKeys(userDetails.get(3));
		stateTextBox.sendKeys(userDetails.get(4));
		zipCodeTextBox.sendKeys(userDetails.get(5));
		phoneNumTextBox.sendKeys(Entity.phoneNumber);
		ssnTextBox.sendKeys(userDetails.get(0));
		userNameTextBox.sendKeys(userDetails.get(0));
		passwordTextBox.sendKeys(userDetails.get(0));
		confPassTextBox.sendKeys(userDetails.get(0));
		registerButton.click();
		Thread.sleep(10000);
		System.out.println("user details registered succesfully" + userDetails );
		Reporter.addStepLog("user details registered succesfully" + userDetails);
		return successfulMessgae.getText();
		
	}

}
