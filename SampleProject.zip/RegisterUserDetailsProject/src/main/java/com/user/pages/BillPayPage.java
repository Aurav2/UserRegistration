package com.user.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.cucumber.listener.Reporter;
import com.user.utils.Entity;

public class BillPayPage extends CommonPageFactoryPage {
	
	public BillPayPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//a[text()='Bill Pay']")
	public WebElement billPayLink;
	
	@FindBy(xpath =  "//form//tbody//tr[1]//input")
	public WebElement payeeNameTextBox;
	
	@FindBy(xpath =  "//form//tbody//tr[2]//input")
	public WebElement payeeAddressTextBox;
	
	@FindBy(xpath =  "//form//tbody//tr[3]//input")
	public WebElement payeeCityTextBox;
	
	@FindBy(xpath =  "//form//tbody//tr[4]//input")
	public WebElement payeeStateTextBox;
	
	@FindBy(xpath =  "//form//tbody//tr[5]//input")
	public WebElement payeeZipCodeTextBox;
	
	@FindBy(xpath =  "//form//tbody//tr[6]//input")
	public WebElement payeePhoneNumTextBox;
	
	@FindBy(xpath =  "//form//tbody//tr[8]//input")
	public WebElement payeeAccountTextBox;
	
	@FindBy(xpath =  "//form//tbody//tr[9]//input")
	public WebElement payeeVerifyAccountTextBox;
	
	
	@FindBy(xpath =  "//form//tbody//tr[11]//input")
	public WebElement payeeAmountTextBox;
	
	@FindBy(xpath = "//input[@value='Send Payment']")
	public WebElement paymentButton;
	
	@FindBy(id = "payeeName")
	public WebElement payeeName;
	
	@FindBy(id = "amount")
	public WebElement payeeAmount;
	
	@FindBy(xpath = "//*[@ng-show='showResult']/p[1]")
	public WebElement paymentSuccesfullMessage;
	
	public void clickRegisterLink() {
		billPayLink.click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	}
	
	public String sendPayment(List<String> userDetails,String payeeName) throws InterruptedException {
		payeeNameTextBox.sendKeys(payeeName);
		payeeAddressTextBox.sendKeys(userDetails.get(2));
		payeeCityTextBox.sendKeys(userDetails.get(3));
		payeeStateTextBox.sendKeys(userDetails.get(4));
		payeeZipCodeTextBox.sendKeys(userDetails.get(5));
		payeePhoneNumTextBox.sendKeys(Entity.phoneNumber);
		payeeAccountTextBox.sendKeys(Entity.accountNumber);
		payeeVerifyAccountTextBox.sendKeys(Entity.accountNumber);
		payeeAmountTextBox.sendKeys(Entity.amount);
		paymentButton.click();
		return paymentSuccesfullMessage.getText();
	}

	public String getPayeeSucessfulMSG() {
		return paymentSuccesfullMessage.getText();
		
	}
}
