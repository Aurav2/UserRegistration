package com.user.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

/**
 * 
 * @author ksaurav
 * This class is responsible for initiating page factory which further will be inherited by page objects class
 */
public class CommonPageFactoryPage {
	protected WebDriver driver;
	
	public CommonPageFactoryPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
		
	}
	
	public WebDriver getDriver() {
		return this.driver;
	}

}
