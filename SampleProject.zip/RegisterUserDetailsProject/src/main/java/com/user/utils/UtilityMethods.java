package com.user.utils;

import java.util.ArrayList;
import java.util.List;

import com.cucumber.listener.Reporter;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class UtilityMethods {
	List<String> user1;
	
	public void CallUserGeneratorAPI(String endPoint) {
		Response res=RestAssured.get("https://randomuser.me/api/");
		Entity.setResponse(res);
		System.out.println("User Generator API called and got response as: "+ res.toString());
		Reporter.addStepLog("User Generator API called and got response as: "+ res.toString());
		
	}
	
	
	
	public List<String> userDetails(){
		JsonPath j=Entity.getResponse().jsonPath();
		user1=new ArrayList<String>();
		user1.add(j.get("results[0].name.first").toString());
		user1.add(j.get("results[0].name.last").toString());
		user1.add(j.get("results[0].location.street.number").toString());
		user1.add(j.get("results[0].location.city").toString());
		user1.add(j.get("results[0].location.state").toString());
		user1.add(j.get("results[0].location.country").toString());
		user1.add(j.get("results[0].location.postcode").toString());
		System.out.println("Extracted user details from API and saved in Aaary: "+ user1);
		Reporter.addStepLog("Extracted user details from API and saved in Aaary: "+ user1);
		return user1;
		
	}

}
