package com.user.utils;

import io.restassured.response.Response;

public class Entity {
	public static Response response = null;
	public  static final String  amount="1000";
	public  static final String  accountNumber="22334455";
	public  static final String  phoneNumber="7833333345";

	public static Response getResponse() {
		return response;
	}

	public static void setResponse(Response response) {
		Entity.response = response;
	}

}
