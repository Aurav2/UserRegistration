package com.user.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Driver {

	public static WebDriver driver;
	static String browserName="chrome";
	
	public static WebDriver getInstance() {
		String  driverPath = null;
		if (browserName.equalsIgnoreCase("chrome")){
			    driverPath = System.getProperty("user.dir") + "/src/test/resources/drivers/chromedriver.exe";
				System.setProperty("webdriver.chrome.driver", driverPath);
				driver = new ChromeDriver();
		}else if (browserName.equalsIgnoreCase("firefox")){

			driver = new FirefoxDriver();
		}

		driver.manage().window().maximize();
        //driver.get(url);
		return driver;
	}
	
	public static void launchURL(String url) {
        driver.get(url);
	}

	public static void closeDriver() {
		if (driver != null) {
			driver.quit();
			driver = null;
		}
	}
}
