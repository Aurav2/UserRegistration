package com.user.runners;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.cucumber.listener.ExtentProperties;
import com.cucumber.listener.Reporter;
import com.user.utils.Driver;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;



@CucumberOptions(
		plugin = {"json:target/cucumber-report.json", "html:target/cucumber-HTMLreport", "com.cucumber.listener.ExtentCucumberFormatter:"},
		features={"src/test/resources"},
		glue={"com.user.stepdefinations"},
		tags={"@test1"},monochrome = true

		)

@Test
public class UserRunner extends AbstractTestNGCucumberTests {


	@BeforeClass
	public void reportSetup() throws IOException{
		
		 ExtentProperties extentProperties = ExtentProperties.INSTANCE; String
		 reportPath = "TestResult/Report_" +new
		 SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(new Date())+".html";
		 extentProperties.setReportPath(reportPath);		 
	}

	@AfterClass
	public void teardown() {

		Driver.closeDriver();
		Reporter.setSystemInfo("user", System.getProperty("user.name"));
        if(System.getProperty("os.name").contains("Windows")){
        	Reporter.setSystemInfo("os", "Windows");
		}else{
			Reporter.setSystemInfo("os", "Linux");
		}   
	}
}

