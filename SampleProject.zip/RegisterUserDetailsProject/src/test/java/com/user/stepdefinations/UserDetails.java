package com.user.stepdefinations;

import org.openqa.selenium.WebDriver;

import com.cucumber.listener.Reporter;
import com.user.pages.BillPayPage;
import com.user.pages.RegisterPage;
import com.user.utils.Driver;
import com.user.utils.UtilityMethods;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.testng.Assert;

import java.util.List;
import java.util.concurrent.TimeUnit;


public class UserDetails extends UtilityMethods{
	
	WebDriver driver=null;
	RegisterPage registerPage;
	BillPayPage billPage;
	UtilityMethods utils=null;
    List<String> firstUserDetails=null;
    List<String> secondUserDetails=null;
    String payeeSuccessfulMsg=null;
    
    public UserDetails() {
		this.driver = Driver.getInstance();
	}
	
    @Given("^Use the user generator to generate random user and save details \"([^\"]*)\"$")
    public void use_the_user_generator_to_generate_random_user_and_save_details(String endPoint) throws Throwable {
    	utils=new UtilityMethods();
    	utils.CallUserGeneratorAPI(endPoint);
    	System.out.println("Use the user generator to generate random user and save details successfully");
		Reporter.addStepLog("Use the user generator to generate random user and save details");
    }
	
	@When("^User navigates to registration page \"([^\"]*)\"$")
	public void user_navigates_to_registration_page(String billPayURL) throws Throwable {
		Driver.launchURL(billPayURL);
		System.out.println("User navigates to registration page successfully");
		Reporter.addStepLog("User navigates to registration page successfully");
	}

	@When("^User click on Register button$")
	public void user_click_on_Register_button() throws Throwable {
		registerPage=new RegisterPage(driver);
		registerPage.clickRegisterLink();
		System.out.println("User click on Register button successfully");
		Reporter.addStepLog("User click on Register button successfully");
	}

	@When("^user registered details succesfully$")
	public void user_registered_details_succesfully() throws Throwable {
		firstUserDetails=utils.userDetails();
		String actualValue=registerPage.registerUserDetails(firstUserDetails);
		Assert.assertEquals(actualValue, "Your account was created successfully. You are now logged in.");
		System.out.println("user registered details succesfully");
		Reporter.addStepLog("user registered details succesfully");
	}

	@When("^user go to bill pay page and transfer a random amount to the another user$")
	public void user_go_to_bill_pay_page_and_transfer_a_random_amount_to_the_another_user() throws Throwable {
		billPage=new BillPayPage(driver);
		billPage.clickRegisterLink();
		utils=new UtilityMethods();
    	utils.CallUserGeneratorAPI("https://randomuser.me/api/");
    	secondUserDetails=utils.userDetails();
    	billPage.sendPayment(secondUserDetails,firstUserDetails.get(0));
    	Thread.sleep(10000);
		System.out.println("transfer a random amount to the another user successfully");
		Reporter.addStepLog("transfer a random amount to the another user successfully");
		
	}

	@Then("^Verify that the payment was successful and to the correct user$")
	public void verify_that_the_payment_was_successful_and_to_the_correct_user() throws Throwable {
		payeeSuccessfulMsg=billPage.getPayeeSucessfulMSG();
		Assert.assertTrue(payeeSuccessfulMsg.contains(firstUserDetails.get(0)), "Reviver Name is NOT varified."+ firstUserDetails.get(0));
		System.out.println("Verified that the payment was successful and to the correct user");
		Reporter.addStepLog("Verified that the payment was successful and to the correct user");
	}}
